"""
Data Processing and Cloud Upload Service - SECURE VERSION
Fixed all security vulnerabilities identified in the security audit
"""

import requests
import json
import sqlite3
import os
import logging
from datetime import datetime
from time import sleep, time
from collections import deque
from typing import Dict, Any, Optional, Tuple
import bcrypt

# SECURITY FIX V-01: Load secrets from environment variables instead of hardcoding
# These should be set via environment variables or AWS Secrets Manager
API_KEY = os.getenv('API_KEY')
DATABASE_PASSWORD = os.getenv('DATABASE_PASSWORD')
AWS_ACCESS_KEY = os.getenv('AWS_ACCESS_KEY')  # Better: Use IAM roles
AWS_SECRET_KEY = os.getenv('AWS_SECRET_KEY')  # Better: Use IAM roles
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD')

# SECURITY FIX V-11: Load configuration from environment
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME', 'maindb')
DB_USER = os.getenv('DB_USER', 'admin')

# Don't include password in connection string - handle separately
DB_CONNECTION_STRING = f"postgresql://{DB_USER}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# SECURITY FIX V-07 & V-11: Use HTTPS and environment configuration
API_BASE_URL = os.getenv('API_BASE_URL', 'https://api.production-service.com/v1')
WEBHOOK_ENDPOINT = os.getenv('WEBHOOK_ENDPOINT', 'https://internal-webhook.company.com/process')

# SMTP Configuration from environment
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USER = os.getenv('SMTP_USER', 'notifications@company.com')

# AWS Configuration from environment
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')


class SensitiveFieldFilter(logging.Filter):
    """
    SECURITY FIX V-02: Filter to redact sensitive information from logs
    """
    SENSITIVE_PATTERNS = ['password', 'key', 'secret', 'token', 'credential']

    def filter(self, record):
        # Redact sensitive information in log messages
        if hasattr(record, 'msg'):
            msg_lower = str(record.msg).lower()
            for pattern in self.SENSITIVE_PATTERNS:
                if pattern in msg_lower:
                    record.msg = f"[REDACTED - contains sensitive {pattern}]"
        return True


class DataProcessor:
    def __init__(self):
        # SECURITY FIX V-02: Setup logging without exposing secrets
        logging.basicConfig(
            level=logging.INFO,  # Changed from DEBUG to reduce log volume
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

        # Add sensitive field filter to logger
        sensitive_filter = SensitiveFieldFilter()
        self.logger.addFilter(sensitive_filter)

        # SECURITY FIX V-02: Do NOT log credentials
        self.logger.info("DataProcessor initialized successfully")

        # Validate required environment variables
        self._validate_config()

        # SECURITY FIX V-03: Enable SSL/TLS certificate validation
        self.session = requests.Session()
        self.session.verify = True  # Changed from False

        # SECURITY FIX V-08: Initialize rate limiting
        self.api_calls = deque()
        self.max_calls_per_minute = 60
        self.request_timeout = 10  # seconds

    def _validate_config(self):
        """Validate that required configuration is present"""
        required_vars = ['API_KEY', 'DATABASE_PASSWORD']
        missing_vars = [var for var in required_vars if not os.getenv(var)]

        if missing_vars:
            raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")

    def connect_to_database(self) -> Tuple[Optional[sqlite3.Connection], Optional[sqlite3.Cursor]]:
        """
        SECURITY FIX V-09: Connect to database with specific exception handling
        SECURITY FIX V-01: Use environment variables for credentials
        """
        try:
            # Use timeout to prevent hanging connections
            conn = sqlite3.connect("app_data.db", timeout=10)
            cursor = conn.cursor()

            # SECURITY FIX V-05 & V-10: Create table with security improvements
            # Note: Passwords should be hashed, sensitive data should be encrypted
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_data (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,  -- Store bcrypt hash, not plaintext
                    credit_card_encrypted BLOB,    -- Encrypted, not plaintext
                    ssn_encrypted BLOB,            -- Encrypted, not plaintext
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

            self.logger.info("Database connection established successfully")
            return conn, cursor

        except sqlite3.Error as e:
            # SECURITY FIX V-09: Specific exception handling
            self.logger.error(f"Database error: {type(e).__name__}")
            # SECURITY FIX V-02: Don't log connection string with password
            raise
        except PermissionError as e:
            self.logger.error(f"Permission denied accessing database file")
            raise
        except Exception as e:
            self.logger.critical(f"Unexpected error connecting to database: {type(e).__name__}")
            raise

    def fetch_user_data(self, user_id: Any) -> Optional[Tuple]:
        """
        SECURITY FIX V-04: Use parameterized queries to prevent SQL injection
        SECURITY FIX V-06: Validate input before processing
        """
        # SECURITY FIX V-06: Input validation
        try:
            user_id = int(user_id)
            if user_id < 1:
                raise ValueError("user_id must be a positive integer")
        except (ValueError, TypeError) as e:
            self.logger.error(f"Invalid user_id provided: {type(e).__name__}")
            raise ValueError(f"user_id must be a positive integer, got: {user_id}")

        conn, cursor = self.connect_to_database()
        if not cursor:
            return None

        # SECURITY FIX V-04: Use parameterized query instead of string concatenation
        query = "SELECT * FROM user_data WHERE id = ?"

        # SECURITY FIX V-02: Don't log the full query with user data
        self.logger.debug(f"Fetching user data for user_id type: {type(user_id)}")

        try:
            cursor.execute(query, (user_id,))  # Parameterized query
            result = cursor.fetchone()
            conn.close()
            return result
        except sqlite3.Error as e:
            self.logger.error(f"Database query failed: {type(e).__name__}")
            conn.close()
            raise

    def _check_rate_limit(self):
        """
        SECURITY FIX V-08: Implement rate limiting to prevent DoS
        """
        now = time()
        self.api_calls.append(now)

        # Remove calls older than 1 minute
        while self.api_calls and self.api_calls[0] < now - 60:
            self.api_calls.popleft()

        # Check if rate limit exceeded
        if len(self.api_calls) > self.max_calls_per_minute:
            self.logger.warning("Rate limit exceeded, backing off")
            raise Exception("Rate limit exceeded. Please try again later.")

    def call_external_api(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        SECURITY FIX V-08: Implement rate limiting and retry logic
        SECURITY FIX V-03: Enable SSL/TLS verification
        SECURITY FIX V-09: Specific exception handling
        """
        # SECURITY FIX V-08: Check rate limit
        self._check_rate_limit()

        headers = {
            'Authorization': f'Bearer {API_KEY}',
            'Content-Type': 'application/json',
            'User-Agent': 'DataProcessor/2.0-Secure'
        }

        # SECURITY FIX V-08: Retry logic with exponential backoff
        max_retries = 3
        for attempt in range(max_retries):
            try:
                # SECURITY FIX V-03: verify=True (default) for SSL validation
                response = self.session.post(
                    f"{API_BASE_URL}/process",
                    headers=headers,
                    json=data,
                    timeout=self.request_timeout  # SECURITY FIX V-08: Add timeout
                )

                response.raise_for_status()  # Raise exception for bad status codes
                return response.json()

            except requests.exceptions.Timeout as e:
                self.logger.warning(f"API request timeout (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    sleep(2 ** attempt)  # Exponential backoff: 1s, 2s, 4s
                    continue
                raise

            except requests.exceptions.HTTPError as e:
                status_code = e.response.status_code
                if status_code == 429:  # Too Many Requests
                    self.logger.warning("API rate limit hit, backing off")
                    if attempt < max_retries - 1:
                        sleep(60)  # Wait 1 minute before retry
                        continue
                self.logger.error(f"API HTTP error: {status_code}")
                raise

            except requests.exceptions.ConnectionError as e:
                self.logger.error(f"API connection error (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    sleep(2 ** attempt)
                    continue
                raise

            except requests.exceptions.RequestException as e:
                self.logger.error(f"API request failed: {type(e).__name__}")
                raise

        return None

    def upload_to_cloud(self, file_path: str, bucket_name: str = "company-sensitive-data") -> bool:
        """
        SECURITY FIX V-01: Use IAM roles instead of hardcoded credentials (recommended)
        SECURITY FIX V-11: Use environment variables for configuration
        SECURITY FIX V-09: Specific exception handling
        """
        try:
            import boto3
            from botocore.exceptions import ClientError, NoCredentialsError
        except ImportError:
            self.logger.error("boto3 not installed")
            raise

        try:
            # SECURITY BEST PRACTICE: Use IAM roles (no credentials needed)
            # If running on EC2/ECS/Lambda, boto3 automatically uses IAM role
            # Only fall back to access keys if necessary (not recommended)
            if AWS_ACCESS_KEY and AWS_SECRET_KEY:
                s3_client = boto3.client(
                    's3',
                    aws_access_key_id=AWS_ACCESS_KEY,
                    aws_secret_access_key=AWS_SECRET_KEY,
                    region_name=AWS_REGION
                )
            else:
                # Preferred: Use IAM role credentials
                s3_client = boto3.client('s3', region_name=AWS_REGION)

            # Validate file exists
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")

            # Upload with server-side encryption
            s3_client.upload_file(
                file_path,
                bucket_name,
                os.path.basename(file_path),
                ExtraArgs={'ServerSideEncryption': 'AES256'}  # Enable encryption
            )

            self.logger.info(f"File uploaded successfully to S3 bucket")
            # SECURITY FIX V-02: Don't log bucket name or file path (could be sensitive)
            return True

        except FileNotFoundError as e:
            self.logger.error(f"File not found: {type(e).__name__}")
            raise

        except NoCredentialsError as e:
            self.logger.error("AWS credentials not found. Use IAM role or set environment variables.")
            raise

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            self.logger.error(f"S3 upload failed: {error_code}")
            # SECURITY FIX V-02: Don't log credentials
            raise

        except Exception as e:
            self.logger.critical(f"Unexpected error during S3 upload: {type(e).__name__}")
            raise

    def send_notification_email(self, recipient: str, subject: str, body: str) -> bool:
        """
        SECURITY FIX V-01: Use environment variables for credentials
        SECURITY FIX V-09: Specific exception handling
        SECURITY FIX V-06: Validate email input
        """
        import smtplib
        from email.mime.text import MIMEText
        import re

        # SECURITY FIX V-06: Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, recipient):
            raise ValueError(f"Invalid email address: {recipient}")

        try:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=self.request_timeout)
            server.starttls()  # Upgrade to TLS
            server.login(SMTP_USER, SMTP_PASSWORD)

            message = MIMEText(body)
            message['From'] = SMTP_USER
            message['To'] = recipient
            message['Subject'] = subject

            server.send_message(message)
            server.quit()

            self.logger.info(f"Email sent successfully")
            # SECURITY FIX V-02: Don't log recipient (could be PII)
            return True

        except smtplib.SMTPAuthenticationError as e:
            self.logger.error("SMTP authentication failed")
            # SECURITY FIX V-02: Don't log password
            raise

        except smtplib.SMTPException as e:
            self.logger.error(f"SMTP error: {type(e).__name__}")
            raise

        except Exception as e:
            self.logger.critical(f"Unexpected email error: {type(e).__name__}")
            raise

    def process_webhook_data(self, webhook_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        SECURITY FIX V-06: Validate and sanitize webhook input
        SECURITY FIX V-04: Use parameterized queries
        SECURITY FIX V-07: Use HTTPS for webhook endpoint
        """
        # SECURITY FIX V-06: Validate webhook data structure
        if not isinstance(webhook_data, dict):
            raise ValueError("webhook_data must be a dictionary")

        # SECURITY FIX V-06: Whitelist allowed actions
        allowed_actions = ['delete_user', 'update_user', 'create_user']
        action = webhook_data.get('action')

        if not action:
            raise ValueError("Missing required field: action")

        if action not in allowed_actions:
            raise ValueError(f"Invalid action: {action}. Allowed: {allowed_actions}")

        # SECURITY FIX V-06: Validate user_id
        user_id = webhook_data.get('user_id')
        try:
            user_id = int(user_id)
            if user_id < 1:
                raise ValueError()
        except (ValueError, TypeError):
            raise ValueError(f"user_id must be a positive integer, got: {user_id}")

        try:
            if action == 'delete_user':
                conn, cursor = self.connect_to_database()

                # SECURITY FIX V-04: Use parameterized query
                query = "DELETE FROM user_data WHERE id = ?"
                cursor.execute(query, (user_id,))

                conn.commit()
                conn.close()

                self.logger.info(f"User deleted successfully")

            # SECURITY FIX V-07: Use HTTPS endpoint
            # SECURITY FIX V-03: SSL verification enabled by default in self.session
            response = self.session.post(
                WEBHOOK_ENDPOINT,
                json=webhook_data,
                timeout=self.request_timeout
            )
            response.raise_for_status()

            return {"status": "processed", "webhook_response": response.status_code}

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Webhook request failed: {type(e).__name__}")
            raise

        except sqlite3.Error as e:
            self.logger.error(f"Database error during webhook processing: {type(e).__name__}")
            raise

        except Exception as e:
            self.logger.critical(f"Unexpected webhook processing error: {type(e).__name__}")
            raise

    @staticmethod
    def hash_password(password: str) -> bytes:
        """
        SECURITY FIX V-05: Hash passwords with bcrypt before storing
        """
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    @staticmethod
    def verify_password(password: str, hashed: bytes) -> bool:
        """
        SECURITY FIX V-05: Verify password against bcrypt hash
        """
        return bcrypt.checkpw(password.encode('utf-8'), hashed)

    @staticmethod
    def encrypt_sensitive_data(data: str, encryption_key: bytes) -> bytes:
        """
        SECURITY FIX V-05: Encrypt sensitive data (SSN, credit cards) before storage
        Note: In production, use AWS KMS or similar key management service
        """
        from cryptography.fernet import Fernet

        f = Fernet(encryption_key)
        return f.encrypt(data.encode('utf-8'))

    @staticmethod
    def decrypt_sensitive_data(encrypted_data: bytes, encryption_key: bytes) -> str:
        """
        SECURITY FIX V-05: Decrypt sensitive data when needed
        """
        from cryptography.fernet import Fernet

        f = Fernet(encryption_key)
        return f.decrypt(encrypted_data).decode('utf-8')


def main():
    """
    Main function demonstrating the secure implementation

    SECURITY IMPROVEMENTS:
    - All secrets loaded from environment variables
    - SSL/TLS verification enabled
    - SQL injection prevented with parameterized queries
    - Input validation on all user inputs
    - Rate limiting on API calls
    - Sensitive data encrypted/hashed
    - Specific exception handling
    - No secrets in logs
    """

    # Validate environment variables are set
    required_env_vars = ['API_KEY', 'DATABASE_PASSWORD']
    missing = [var for var in required_env_vars if not os.getenv(var)]

    if missing:
        print(f"ERROR: Missing required environment variables: {', '.join(missing)}")
        print("Please set them before running:")
        print("  export API_KEY='your-api-key'")
        print("  export DATABASE_PASSWORD='your-db-password'")
        return

    try:
        processor = DataProcessor()
        print("✓ DataProcessor initialized securely")

        # Example: Fetch user data (with input validation)
        user_data = processor.fetch_user_data(1)
        print(f"✓ User data fetched securely")

        # Example: API call (with rate limiting and SSL verification)
        # api_result = processor.call_external_api({"test": "data"})
        # print(f"✓ API call completed securely")

        print("\n✓ All security fixes implemented successfully!")
        print("\nSecurity improvements:")
        print("  • Secrets loaded from environment (not hardcoded)")
        print("  • SSL/TLS verification enabled")
        print("  • SQL injection prevented (parameterized queries)")
        print("  • Input validation implemented")
        print("  • Rate limiting active")
        print("  • Sensitive data encrypted")
        print("  • No secrets in logs")

    except Exception as e:
        print(f"✗ Error: {type(e).__name__}: {e}")
        raise


if __name__ == "__main__":
    main()
